Pokanikki - A web service for recording and analysing game scores and results for a squash club. Web-palvelu squash-seuran pelitulosten kirjaamiseen ja analysointiin.

Built with:

	Node.js
	Express.js
	MongoDb
	Jade
	Moment.js
	Foundation 4
	Knockout.js
	jQuery.transit
	
	jQuery Mobile
	jQueryUI
	iScroll


Built on top of node-login by Stephen Braitsch, though not much code survives and most things haven't gotten better.